-- Refrigeración 360: esquema inicial (revisar y completar políticas antes de producción)
create extension if not exists pgcrypto;

create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  currency text not null default 'COP',
  timezone text not null default 'America/Bogota',
  created_at timestamptz not null default now()
);

create table if not exists profiles (
  id uuid primary key, -- debe coincidir con auth.users.id
  organization_id uuid references organizations(id) on delete restrict,
  full_name text not null,
  phone text,
  role text not null check(role in ('owner','secretary','technician','customer','partner_technician')),
  created_at timestamptz not null default now()
);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  name text not null,
  phone text,
  email text,
  customer_type text default 'residential',
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists customer_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  address text not null,
  city text,
  region text,
  latitude numeric,
  longitude numeric,
  notes text
);

create table if not exists equipment (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  customer_id uuid not null references customers(id) on delete cascade,
  address_id uuid references customer_addresses(id),
  equipment_type text not null,
  brand text,
  model text,
  serial_number text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists service_orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  order_number bigint generated always as identity,
  customer_id uuid not null references customers(id),
  equipment_id uuid references equipment(id),
  address_id uuid references customer_addresses(id),
  description text not null,
  priority text not null default 'normal' check(priority in ('low','normal','high','urgent')),
  status text not null default 'pending_assignment',
  scheduled_at timestamptz,
  estimated_duration_minutes integer,
  quoted_amount numeric(14,2) default 0,
  final_amount numeric(14,2),
  created_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists service_assignments (
  id uuid primary key default gen_random_uuid(),
  service_order_id uuid not null references service_orders(id) on delete cascade,
  technician_id uuid not null references profiles(id),
  assigned_by uuid references profiles(id),
  status text not null default 'assigned' check(status in ('assigned','accepted','rejected','completed')),
  response_note text,
  assigned_at timestamptz not null default now(),
  responded_at timestamptz,
  unique(service_order_id, technician_id)
);

create table if not exists service_status_events (
  id uuid primary key default gen_random_uuid(),
  service_order_id uuid not null references service_orders(id) on delete cascade,
  actor_id uuid references profiles(id),
  old_status text,
  new_status text not null,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists service_diagnostics (
  id uuid primary key default gen_random_uuid(),
  service_order_id uuid not null references service_orders(id) on delete cascade,
  technician_id uuid references profiles(id),
  diagnosis text,
  work_performed text,
  created_at timestamptz not null default now()
);

create table if not exists inventory_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  sku text,
  name text not null,
  unit text not null default 'unit',
  cost numeric(14,2) default 0,
  sale_price numeric(14,2) default 0,
  stock_quantity numeric(14,3) not null default 0,
  minimum_stock numeric(14,3) not null default 0
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  category text not null,
  description text,
  amount numeric(14,2) not null check(amount>=0),
  expense_date date not null default current_date,
  recorded_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id),
  service_order_id uuid references service_orders(id),
  amount numeric(14,2) not null check(amount>0),
  method text,
  reference text,
  received_at timestamptz not null default now(),
  recorded_by uuid references profiles(id)
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id),
  actor_id uuid references profiles(id),
  action text not null,
  entity text not null,
  entity_id uuid,
  details jsonb,
  created_at timestamptz not null default now()
);

-- RLS deliberately not enabled here automatically: create role policies and verify
-- access rules with tests before enabling production access.
-- This schema is a starter and is not yet production-ready.
