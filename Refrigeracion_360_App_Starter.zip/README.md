# Refrigeración 360 — starter

Este starter es un prototipo frontend funcional para registrar órdenes y clientes, cambiar estados, abrir Google Maps y WhatsApp, y guardar datos en el navegador (localStorage).

## Requisitos
- Node.js 18+ recomendado
- npm

## Ejecutar
1. Extrae el ZIP.
2. Abre una terminal dentro de la carpeta.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre la URL que Vite indique (normalmente `http://localhost:5173`).

## Estado actual / limitaciones
- **Persistencia demo local:** datos en localStorage de este navegador/dispositivo. No sincroniza entre trabajadores ni dispositivos.
- No hay autenticación ni roles reales todavía.
- Los técnicos y órdenes de demo son ejemplos.
- Cambiar el estado es una función local; aún no es un flujo de aceptación autenticado.
- Finanzas es una vista ilustrativa y no contabilidad.
- Push, contratos, inventario, nómina y marketplace no están implementados.
- Google Maps y WhatsApp se abren mediante enlaces; no es una integración API.
- No utilizar con datos reales de clientes hasta implementar backend, auth, RLS, política de datos y respaldos.

## Backend central recomendado: Supabase
Supabase es PostgreSQL con servicios adicionales. Si se desea infraestructura propia, se puede autoalojar Supabase (Docker) o desplegar PostgreSQL/backend propios. Una base local en un único dispositivo no permite sincronización multiusuario confiable.

El archivo `supabase/schema.sql` contiene un esquema inicial orientativo. Antes de producción, revisarlo, completar permisos/RLS, migraciones y pruebas. El frontend aún no está conectado a ese esquema.

## Próximos pasos
1. Implementar Supabase Auth, organizaciones y perfiles.
2. Implementar RLS y roles.
3. Conectar CRUD de clientes, órdenes y asignaciones.
4. Implementar aceptación de órdenes, eventos, notificaciones y push.
5. Agregar finanzas, caja, inventario, contratos, garantías y marketplace por fases.
